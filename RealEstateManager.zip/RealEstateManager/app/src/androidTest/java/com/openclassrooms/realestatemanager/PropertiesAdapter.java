package com.openclassrooms.realestatemanager;

public class PropertiesAdapter {
}
