package com.openclassrooms.realestatemanager;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.openclassrooms.realestatemanager.Properties.PropertiesAdapter;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv;
    private PropertiesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv = findViewById(R.id.properties_rv);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new PropertiesAdapter();
        rv.setAdapter(adapter);
    }
}
