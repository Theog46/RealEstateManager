package com.openclassrooms.realestatemanager.Properties;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PropertiesHolder extends RecyclerView.ViewHolder {
    public PropertiesHolder(@NonNull View itemView) {
        super(itemView);
    }
}
