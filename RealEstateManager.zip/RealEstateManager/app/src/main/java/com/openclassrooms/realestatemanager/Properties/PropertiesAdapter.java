package com.openclassrooms.realestatemanager.Properties;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PropertiesAdapter extends RecyclerView.Adapter<PropertiesHolder> {

    @Override
    public PropertiesHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull PropertiesHolder propertiesHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
